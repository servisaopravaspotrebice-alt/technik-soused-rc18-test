(()=>{'use strict';
const URL='https://gafwkinjlggpvwmxanck.supabase.co';
const KEY='sb_publishable_U-H_YOkvoQqE3IorF8QLPQ_sJk04PTI';
const $=id=>document.getElementById(id);
const client=()=>window.supabase?.createClient?.(URL,KEY,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:false}});
const add=(parent,tag,text,cls)=>{const n=document.createElement(tag);if(cls)n.className=cls;n.textContent=String(text??'');parent.appendChild(n);return n};
const notice=(id,text,bad=false)=>{const x=$(id);if(!x)return;x.textContent=text;x.className='status'+(bad?' error':'')};
const time=x=>x?new Date(x).toLocaleString('ru-RU',{dateStyle:'short',timeStyle:'short',timeZone:'Europe/Prague'}):'—';
async function rpc(c,name,args){const {data,error}=await c.rpc(name,args);if(error)throw new Error(error.message||'Ошибка Supabase');return data}
async function signedIn(c){const {data,error}=await c.auth.getUser();if(error)throw error;return data?.user||null}
async function owner(c){const u=await signedIn(c);if(!u)return false;const {data,error}=await c.from('ts_user_roles').select('role').eq('user_id',u.id).maybeSingle();if(error)throw error;return data?.role==='owner'}
const error=e=>String(e?.message||e||'Неизвестная ошибка');
window.TSRC18={client,$,add,notice,time,rpc,signedIn,owner,error};
})();
