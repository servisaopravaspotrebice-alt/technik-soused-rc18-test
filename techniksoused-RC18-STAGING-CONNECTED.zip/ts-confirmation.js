/* Technik Soused: confirmation shown only after a locally saved DEMO request.
   Production must call TSConfirm.show({live:true}) after a successful API response. */
(function(){
 'use strict';
 const CSS = `
 #tsFormConfirm[hidden]{display:none!important}
 #tsFormConfirm{position:fixed;inset:0;z-index:2147483000;display:flex;align-items:center;justify-content:center;padding:16px;background:rgba(13,35,60,.79)}
 #tsFormConfirm .ts-confirm-box{box-sizing:border-box;width:min(100%,580px);max-height:calc(100dvh - 30px);overflow:auto;background:#fff;color:#163550;border-radius:20px;padding:clamp(24px,5vw,40px);box-shadow:0 22px 75px #06182d66;text-align:center;font-family:system-ui,-apple-system,'Segoe UI',Arial,sans-serif}
 #tsFormConfirm .ts-confirm-icon{display:grid;place-items:center;margin:0 auto 16px;background:#e7f8ed;color:#077b45;border-radius:50%;height:76px;width:76px;font-weight:900;font-size:46px}
 #tsFormConfirm[data-demo="true"] .ts-confirm-icon{background:#fff3d8;color:#995500}
 #tsFormConfirm h2{margin:0 0 14px;color:#102f53;font-size:clamp(25px,5.5vw,35px);line-height:1.18}
 #tsFormConfirm p{font-size:clamp(17px,3.9vw,22px);line-height:1.48;margin:12px 0 20px}
 #tsFormConfirm .ts-confirm-warning{padding:13px 15px;background:#fff4df;border:1px solid #efc16b;border-radius:12px;font-size:16px;line-height:1.5;color:#674209;text-align:left}
 #tsFormConfirm button{border:0;width:100%;min-height:56px;margin-top:12px;border-radius:12px;background:#0c6bea;color:white;font-size:20px;font-weight:800;cursor:pointer}
 #tsFormConfirm button:focus-visible{outline:4px solid #ffbf3c;outline-offset:3px}
 `;
 let priorFocus = null;
 function init(){
  if(document.getElementById('tsFormConfirm')) return;
  const style=document.createElement('style');style.id='ts-form-confirm-style';style.textContent=CSS;document.head.appendChild(style);
  const overlay=document.createElement('div');overlay.id='tsFormConfirm';overlay.hidden=true;overlay.setAttribute('role','dialog');overlay.setAttribute('aria-modal','true');overlay.setAttribute('aria-labelledby','tsFormConfirmTitle');overlay.setAttribute('aria-describedby','tsFormConfirmText');
  overlay.innerHTML='<div class="ts-confirm-box"><span class="ts-confirm-icon" aria-hidden="true">✓</span><h2 id="tsFormConfirmTitle"></h2><p id="tsFormConfirmText"></p><div class="ts-confirm-warning" id="tsFormConfirmWarning" hidden></div><button id="tsFormConfirmClose" type="button">Rozumím, děkuji</button></div>';
  document.body.appendChild(overlay);
  const close=overlay.querySelector('button');close.addEventListener('click',()=>{overlay.hidden=true;document.body.style.overflow='';priorFocus?.focus({preventScroll:true});});
  overlay.addEventListener('click',e=>{if(e.target===overlay)close.click()});
  overlay.addEventListener('keydown',e=>{if(e.key==='Tab'){e.preventDefault();close.focus()}if(e.key==='Escape'){e.preventDefault();close.focus()}});
 }
 function show(o={}){
  init();const demo=o.demo!==false;const overlay=document.getElementById('tsFormConfirm');priorFocus=document.activeElement;overlay.dataset.demo=String(demo);
  overlay.querySelector('.ts-confirm-icon').textContent=demo?'i':'✓';
  overlay.querySelector('#tsFormConfirmTitle').textContent=demo?'Poptávka byla uložena v ukázce':'Děkujeme! Poptávka byla odeslána.';
  overlay.querySelector('#tsFormConfirmText').textContent=demo?'Ukázkový formulář funguje. V ostré verzi vám po skutečném přijetí poptávky zavoláme na uvedené telefonní číslo.':'Vaši poptávku jsme přijali. Nyní prosím vyčkejte na telefonát operátora na uvedeném čísle.';
  const w=overlay.querySelector('#tsFormConfirmWarning');w.hidden=!demo;w.textContent=demo?'POZOR: Toto je pouze DEMO. Poptávka se neodeslala na server ani operátorovi. Na telefonát nyní nečekejte.':'';
  overlay.hidden=false;document.body.style.overflow='hidden';overlay.querySelector('button').focus();
 }
 window.TSConfirm={show};
 // Trade-portal requests are currently stored in localStorage: confirmation must explicitly say DEMO.
 function wireDemo(selector){const node=document.querySelector(selector);if(!node)return;
  let last='';const observer=new MutationObserver(()=>{const message=node.textContent||'';if(!node.hidden&&message!==last && /(?:DEMO|Testovací|uložen)/i.test(message)){last=message;show({demo:true});}});
  observer.observe(node,{subtree:true,childList:true,characterData:true,attributes:true,attributeFilter:['hidden']});
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>{init();wireDemo('#orderSuccess');wireDemo('#request-msg')},{once:true});
 else{init();wireDemo('#orderSuccess');wireDemo('#request-msg')}
})();
