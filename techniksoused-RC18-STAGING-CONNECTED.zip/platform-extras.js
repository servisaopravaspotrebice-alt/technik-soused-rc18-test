/* Demonstration only: localStorage is not authentication, not server verified. */
(()=>{'use strict';
const KEY='ts_platform_feedback_demo_v1', WA_KEY='ts_whatsapp_number_v1', TTL=3600000;
const $=s=>document.querySelector(s);
const escapeHTML=v=>String(v??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
function state(){try{let d=JSON.parse(localStorage.getItem(KEY));if(d&&Array.isArray(d.invites)&&Array.isArray(d.reviews))return d;}catch{}return {invites:[],reviews:[]};}
function save(d){localStorage.setItem(KEY,JSON.stringify(d));}
function openReview(){const modal=$('#ts-platform-review-modal');if(!modal)return;modal.hidden=false;$('#ts-platform-review-code')?.focus();}
function closeReview(){const modal=$('#ts-platform-review-modal');if(modal)modal.hidden=true;}
function render(){let d=state(),out=$('#ts-platform-review-published');if(!out)return;let reviews=d.reviews.filter(r=>r.status==='published').slice(-6).reverse();out.innerHTML=reviews.length?reviews.map(r=>`<article class="ts-pr-entry"><div class="ts-pr-stars">${'★'.repeat(Number(r.rating))}${'☆'.repeat(5-Number(r.rating))}</div><strong>${escapeHTML(r.name||'Zákazník platformy')}</strong><p>${escapeHTML(r.text)}</p><small>Ověřená pozvánka · hodnocení služby Technik Soused</small></article>`).join(''):'<p>Dosud nejsou zveřejněná hodnocení platformy.</p>';
}
function setupWhatsApp(){let raw=(localStorage.getItem(WA_KEY)||'').replace(/\D/g,'');const a=$('#ts-whatsapp-contact');if(!a)return;
 if(/^420\d{9}$/.test(raw)){a.href='https://wa.me/'+raw+'?text='+encodeURIComponent('Dobrý den, potřebuji pomoc s poptávkou na Technik Soused.');a.hidden=false;}
 else{a.hidden=true;a.removeAttribute('href');}
}
function tokenFromUrl(){return new URLSearchParams(location.search).get('platform_review')||new URLSearchParams(location.hash.replace(/^#/, '')).get('platform_review')||'';}
function submit(ev){ev.preventDefault();let token=tokenFromUrl(),d=state(),invite=d.invites.find(i=>i.token===token),status=$('#ts-platform-review-status');
 if(!invite){status.textContent='Neplatný nebo chybějící osobní odkaz. Požádejte podporu o zaslání odkazu.';return;}
 if(invite.used||invite.expires<=Date.now()){status.textContent='Tento odkaz již byl použit nebo vypršela jeho platnost (60 minut).';return;}
 const code=$('#ts-platform-review-code').value.trim(),text=$('#ts-platform-review-text').value.trim(),name=$('#ts-platform-review-name').value.trim(),rating=Number($('#ts-platform-review-rating').value);
 if(code!==invite.code||!text||rating<1||rating>5){status.textContent='Zkontrolujte jednorázový kód, hodnocení a text.';return;}
 if(text.length>1500){status.textContent='Text hodnocení je příliš dlouhý.';return;}
 invite.used=true;invite.usedAt=Date.now();d.reviews.push({id:invite.token,name:name.slice(0,60),text:text.slice(0,1500),rating,source:'invitation',status:'pending',at:Date.now()});save(d);
 status.textContent='Děkujeme, hodnocení bylo odesláno ke schválení administrátorem.';ev.currentTarget.querySelector('button[type="submit"]').disabled=true;
}
function init(){render();setupWhatsApp();$('#ts-platform-review-open')?.addEventListener('click',openReview);$('#ts-platform-review-close')?.addEventListener('click',closeReview);$('#ts-platform-review-form')?.addEventListener('submit',submit);
 if(tokenFromUrl())openReview();window.addEventListener('storage',ev=>{if(ev.key===KEY)render();if(ev.key===WA_KEY)setupWhatsApp()});}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
